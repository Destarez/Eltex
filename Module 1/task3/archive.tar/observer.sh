#!/bin/bash

# Path to log and conf file
CONF_FILE="observer.conf"
LOG_FILE="observer.log"

if [[ ! -f "$CONF_FILE" ]]; then
  echo "Конфигурационный файл не найден: $CONF_FILE"
  exit 1
fi

if [[ ! -f "$LOG_FILE" ]]; then
  touch "$LOG_FILE"
  echo "$LOG_FILE создан" >> "$LOG_FILE"
fi

# Read conf file
while IFS= read -r script; do

        # Checking script in the list of working process
        if ! pgrep -fx "$script" > /dev/null; then
                nohup bash "$script" > /dev/null 2>&1 &
                echo "$(date '+%Y-%m-%d %H:%M:%S') - Скрипт $script был перезапущен" >> "$LOG_FILE"
        fi

done < "$CONF_FILE"
