#!/bin/bash

# Report file name
SCRIPT_NAME=$(basename "$0")
LOG_FILE="report_${SCRIPT_NAME}.log"

if [ ! -f "$LOG_FILE" ]; then
    touch "$LOG_FILE"
    echo "$LOG_FILE создан" >> "$LOG_FILE"
fi

# PID, date and time
PID=$$
DATE_TIME=$(date "+%Y-%m-%d %H:%M:%S")

# Add start message in log
echo "[$PID] $DATE_TIME Скрипт запущен" >> "$LOG_FILE"

# Generate random number
SLEEP_TIME=$((RANDOM % 1771 + 30))

# Sleep
sleep $SLEEP_TIME

# Date, time and duration
DATE_TIME_END=$(date "+%Y-%m-%d %H:%M:%S")
DURATION=$((SLEEP_TIME / 60))

# Add end message in log
echo "[$PID] $DATE_TIME_END Скрипт завершился, работал $DURATION минут" >> "$LOG_FILE"
